import { GlobalLoader } from '@kit/ui/global-loader';

export default GlobalLoader;
